const pluginId = "com.blocklang.acode";

const svgIconUrl = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' rx='20' fill='%232a2a2a'/%3E%3Cg fill='none' stroke='%23ffffff' stroke-width='5' stroke-linejoin='round'%3E%3Crect x='25' y='20' width='15' height='60'/%3E%3Cpolygon points='45,20 70,20 75,32.5 70,45 45,45'/%3E%3Cpolygon points='45,55 75,55 80,67.5 75,80 45,80'/%3E%3C/g%3E%3C/svg%3E";

class BlockPlugin {
    constructor() {
        // Store bound references so we can properly remove listeners later
        this._onFileUpdate = this.onFileUpdate.bind(this);
    }

    async init($page) {
        const style = document.createElement('style');
        style.id = 'block-plugin-style';
        style.innerHTML = "\n            .icon-block-lang {\n                background-image: url(\"" + svgIconUrl + "\");\n                background-size: cover;\n                background-repeat: no-repeat;\n                background-position: center;\n                width: 26px;\n                height: 26px;\n                display: inline-block;\n                margin: 11px 8px 0 8px;\n                cursor: pointer;\n                border-radius: 4px;\n                float: right;\n            }\n            .file_type_blk::before, .file_type_block::before {\n                content: '' !important;\n                display: inline-block !important;\n                width: 1.1em;\n                height: 1.1em;\n                background-image: url(\"" + svgIconUrl + "\");\n                background-size: contain;\n                background-repeat: no-repeat;\n                background-position: center;\n                vertical-align: middle;\n            }\n        ";
        document.head.appendChild(style);

        this.$btn = document.createElement('span');
        this.$btn.className = 'icon action-btn';
        this.$btn.onclick = this.showAbout.bind(this);
        this.$btn.style.backgroundImage = `url("${svgIconUrl}")`;
        this.$btn.style.backgroundSize = '20px';
        this.$btn.style.backgroundRepeat = 'no-repeat';
        this.$btn.style.backgroundPosition = 'center';

        this.$runBtn = document.createElement('span');
        this.$runBtn.className = 'icon play_arrow action-btn';
        this.$runBtn.onclick = this.runBlockCode.bind(this);
        this.$runBtn.style.color = '#4caf50';
        this.$runBtn.style.fontSize = '24px';

        if (window.ace) {
            ace.config.loadModule("ace/snippets/html", function(m) {
                const snippetManager = ace.require("ace/snippets").snippetManager;
                if (!m) m = { snippets: [] };
                m.snippets = m.snippets || [];
                const mySnippets = [
                    { name: "server", content: "<server port=\"${1:8080}\">\n  $2\n</server>", tabTrigger: "server" },
                    { name: "route", content: "<route path=\"${1:/}\">\n  $2\n</route>", tabTrigger: "route" },
                    { name: "python", content: "<py>\n$1\n</py>", tabTrigger: "python" },
                    { name: "javascript", content: "<js>\n$1\n</js>", tabTrigger: "js" },
                    { name: "php", content: "<php>\n$1\n</php>", tabTrigger: "php" },
                    { name: "powershell", content: "<ps>\n$1\n</ps>", tabTrigger: "ps" },
                    { name: "lua", content: "<lua>\n$1\n</lua>", tabTrigger: "lua" },
                    { name: "ruby", content: "<ruby>\n$1\n</ruby>", tabTrigger: "ruby" },
                    { name: "sql", content: "<sql>\n$1\n</sql>", tabTrigger: "sql" },
                    { name: "html", content: "<html>\n$1\n</html>", tabTrigger: "html" },
                    { name: "json", content: "<json>\n$1\n</json>", tabTrigger: "json" },
                    { name: "del", content: "<del>\n$1\n</del>", tabTrigger: "del" }
                ];
                m.snippets.push.apply(m.snippets, mySnippets);
                snippetManager.register(m.snippets, "html");
            });
        }

        editorManager.on('switch-file', this._onFileUpdate);
        editorManager.on('rename-file', this._onFileUpdate);
        this._onFileUpdate();
        
        // Register a command and hotkey (Ctrl+R / Cmd+R)
        editorManager.editor.commands.addCommand({
            name: 'Run Block Engine Code',
            bindKey: {win: 'Ctrl-R', mac: 'Command-R'},
            exec: this.runBlockCode.bind(this)
        });
    }

    onFileUpdate() {
        const file = editorManager.activeFile;
        const isBlock = file && file.name && (file.name.endsWith('.blk') || file.name.endsWith('.block'));
        if (isBlock) {
            editorManager.editor.getSession().setMode('ace/mode/html');
            const header = document.querySelector('#main-header') || document.querySelector('header');
            if (header && !this.$btn.parentElement) {
                header.appendChild(this.$btn);
                header.appendChild(this.$runBtn);
            }
        } else {
            if (this.$btn.parentElement) this.$btn.parentElement.removeChild(this.$btn);
            if (this.$runBtn.parentElement) this.$runBtn.parentElement.removeChild(this.$runBtn);
        }
    }

    showAbout() {
        const html = "<div style=\"text-align: center;\">" +
            "<img src=\"" + svgIconUrl + "\" style=\"width: 100px; height: 100px; border-radius: 16px; margin-bottom: 12px; box-shadow: 0 4px 8px rgba(0,0,0,0.3);\">" +
            "<h3 style=\"margin: 0; color: #fff; font-family: 'Inter', sans-serif;\">Block Engine</h3>" +
            "<p style=\"margin: 6px 0 16px 0; color: #aaa; font-size: 14px;\">Version 1.0.2</p>" +
            "</div>";
        window.acode.alert('About Extension', html);
    }

    async runBlockCode() {
        let serverUrl = window.localStorage.getItem('block_server_ip');
        if (!serverUrl) {
            let res = await window.acode.prompt('Enter PC Engine API URL', 'http://192.168.1.100:8080/api/run');
            if (!res) return;
            if (res.endsWith('/')) res = res.substring(0, res.length - 1);
            if (!res.endsWith('/api/run')) res = res + '/api/run';
            window.localStorage.setItem('block_server_ip', res);
            serverUrl = res;
        }

        const code = editorManager.editor.getValue();
        if (window.toast) window.toast('Running code...', 1000);

        try {
            const response = await fetch(serverUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'text/plain' },
                body: code
            });
            
            if (!response.ok) {
                // Server returned error status - try to get error details
                let errorMsg = 'Server returned status ' + response.status;
                try {
                    const errResult = await response.json();
                    if (errResult && errResult.error) errorMsg = errResult.error;
                } catch (_) { /* Not JSON, use default message */ }
                window.acode.alert('Execution Error', "<div style=\"color:#ff5555; text-align:left;\">" + errorMsg + "</div>");
                return;
            }

            const result = await response.json();
            
            if (result.status === 'success') {
                const output = (result.output != null) ? result.output : '(No output)';
                const safeOutput = output.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
                const html = "<div style=\"background:#1e1e1e; color:#d4d4d4; padding:10px; border-radius:8px; font-family:monospace; max-height:300px; overflow-y:auto; white-space:pre-wrap; text-align:left;\">" + safeOutput + "</div>";
                window.acode.alert('Execution Result', html);
            } else {
                const errorText = (result.error != null) ? result.error : 'Unknown error';
                window.acode.alert('Execution Error', "<div style=\"color:#ff5555; text-align:left;\">" + errorText + "</div>");
            }
        } catch (e) {
            window.acode.alert('Connection Failed', "Could not connect to " + serverUrl + ". Is the PC engine running?\nError: " + e.message);
            window.localStorage.removeItem('block_server_ip');
        }
    }

    async destroy() {
        // Remove event listeners using the same bound reference
        editorManager.off('switch-file', this._onFileUpdate);
        editorManager.off('rename-file', this._onFileUpdate);
        
        // Remove custom command
        try {
            editorManager.editor.commands.removeCommand('Run Block Engine Code');
        } catch (_) {}

        // Clean up DOM
        const style = document.getElementById('block-plugin-style');
        if (style) style.remove();
        if (this.$btn.parentElement) this.$btn.parentElement.removeChild(this.$btn);
        if (this.$runBtn.parentElement) this.$runBtn.parentElement.removeChild(this.$runBtn);
    }
}

if (window.acode) {
    const acodePlugin = new BlockPlugin();
    acode.setPluginInit(pluginId, function(baseUrl, $page, options) {
        acodePlugin.baseUrl = baseUrl;
        acodePlugin.init($page);
    });
    
    acode.setPluginUnmount(pluginId, function() {
        acodePlugin.destroy();
    });
}
