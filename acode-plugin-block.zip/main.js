const pluginId = "com.blocklang.acode";

class BlockPlugin {
    async init($page) {
        // Setup Header Icon UI
        const style = document.createElement('style');
        style.id = 'block-plugin-style';
        style.innerHTML = `
            .icon-block-lang {
                background-image: url('${this.baseUrl}icon.png');
                background-size: cover;
                background-repeat: no-repeat;
                background-position: center;
                width: 26px;
                height: 26px;
                display: inline-block;
                margin: 11px 8px 0 8px;
                cursor: pointer;
                border-radius: 4px;
                float: right;
            }
        `;
        document.head.appendChild(style);

        this.$btn = document.createElement('span');
        this.$btn.className = 'icon icon-block-lang action-btn';
        this.$btn.onclick = this.showAbout.bind(this);

        this.$runBtn = document.createElement('span');
        this.$runBtn.className = 'icon action-btn';
        this.$runBtn.innerHTML = '▶';
        this.$runBtn.style.color = '#4caf50';
        this.$runBtn.style.fontWeight = 'bold';
        this.$runBtn.style.fontSize = '20px';
        this.$runBtn.style.padding = '10px 10px 0 10px';
        this.$runBtn.style.float = 'right';
        this.$runBtn.style.cursor = 'pointer';
        this.$runBtn.onclick = this.runBlockCode.bind(this);

        // Register Custom Ace Mode for Block Language
        if (window.ace) {
            ace.define("ace/mode/block_highlight_rules", ["require", "exports", "module", "ace/lib/oop", "ace/mode/html_highlight_rules", "ace/mode/python_highlight_rules", "ace/mode/php_highlight_rules", "ace/mode/javascript_highlight_rules", "ace/mode/powershell_highlight_rules"], function(require, exports, module) {
                var oop = require("ace/lib/oop");
                var HtmlHighlightRules = require("ace/mode/html_highlight_rules").HtmlHighlightRules;
                var PythonRules = require("ace/mode/python_highlight_rules").PythonHighlightRules;
                var PhpRules = require("ace/mode/php_highlight_rules").PhpHighlightRules;
                var JsRules = require("ace/mode/javascript_highlight_rules").JavaScriptHighlightRules;
                var PsRules = require("ace/mode/powershell_highlight_rules").PowershellHighlightRules;

                var BlockHighlightRules = function() {
                    HtmlHighlightRules.call(this);

                    var addEmbed = (langName, RulesClass) => {
                        this.$rules.start.unshift({
                            token: "meta.tag.block.xml",
                            regex: "<" + langName + ">",
                            next: langName + "-start"
                        });
                        this.embedRules(RulesClass, langName + "-", [{
                            token: "meta.tag.block.xml",
                            regex: "</" + langName + ">",
                            next: "start"
                        }]);
                    };

                    if (PythonRules) addEmbed("python", PythonRules);
                    if (PhpRules) addEmbed("php", PhpRules);
                    if (JsRules) addEmbed("js", JsRules);
                    if (PsRules) addEmbed("ps", PsRules);

                    this.normalizeRules();
                };

                oop.inherits(BlockHighlightRules, HtmlHighlightRules);
                exports.BlockHighlightRules = BlockHighlightRules;
            });

            ace.define("ace/mode/block", ["require", "exports", "module", "ace/lib/oop", "ace/mode/text", "ace/mode/block_highlight_rules"], function(require, exports, module) {
                var oop = require("ace/lib/oop");
                var TextMode = require("ace/mode/text").Mode;
                var BlockHighlightRules = require("ace/mode/block_highlight_rules").BlockHighlightRules;

                var Mode = function() {
                    this.HighlightRules = BlockHighlightRules;
                };
                oop.inherits(Mode, TextMode);
                exports.Mode = Mode;
            });

            // Register Snippets for block mode
            ace.config.loadModule("ace/snippets/block", (m) => {
                const snippetManager = ace.require("ace/snippets").snippetManager;
                if (!m) m = { snippets: [] };
                m.snippets = m.snippets || [];
                const mySnippets = [
                    { name: "server", content: "<server port=\"${1:8080}\">\n  $2\n</server>", tabTrigger: "server" },
                    { name: "route", content: "<route path=\"${1:/api}\">\n  $2\n</route>", tabTrigger: "route" },
                    { name: "python", content: "<python>\n$1\n</python>", tabTrigger: "python" },
                    { name: "php", content: "<php>\n$1\n</php>", tabTrigger: "php" },
                    { name: "js", content: "<js>\n$1\n</js>", tabTrigger: "js" },
                    { name: "ps", content: "<ps>\n$1\n</ps>", tabTrigger: "ps" },
                    { name: "html", content: "<html>\n$1\n</html>", tabTrigger: "html" },
                    { name: "json", content: "<json>\n$1\n</json>", tabTrigger: "json" }
                ];
                m.snippets.push(...mySnippets);
                snippetManager.register(m.snippets, "block");
            });
        }

        // Bind file updates
        editorManager.on('switch-file', this.onFileUpdate.bind(this));
        editorManager.on('rename-file', this.onFileUpdate.bind(this));
        this.onFileUpdate();
    }

    onFileUpdate() {
        const file = editorManager.activeFile;
        const isBlock = file && (file.filename.endsWith('.blk') || file.filename.endsWith('.block'));
        if (isBlock) {
            editorManager.editor.getSession().setMode('ace/mode/block');
            
            if (!this.$btn.parentElement) {
                const header = document.querySelector('#main-header') || document.querySelector('header');
                if (header) {
                    header.appendChild(this.$btn);
                    header.appendChild(this.$runBtn);
                }
            }
        } else {
            if (this.$btn.parentElement) {
                this.$btn.parentElement.removeChild(this.$btn);
            }
            if (this.$runBtn.parentElement) {
                this.$runBtn.parentElement.removeChild(this.$runBtn);
            }
        }
    }

    showAbout() {
        const html = `
            <div style="text-align: center;">
                <img src="${this.baseUrl}icon.png" style="width: 100px; height: 100px; border-radius: 16px; margin-bottom: 12px; box-shadow: 0 4px 8px rgba(0,0,0,0.3);">
                <h3 style="margin: 0; color: #fff; font-family: 'Inter', sans-serif;">Block Engine</h3>
                <p style="margin: 6px 0 16px 0; color: #aaa; font-size: 14px;">Version 1.0.0</p>
                <a href="https://github.com/Antigravity/BlockEngine" style="display: inline-block; padding: 8px 16px; background-color: #4da6ff; color: #fff; text-decoration: none; border-radius: 8px; font-weight: bold;">Visit Website</a>
            </div>
        `;
        window.acode.alert('About Extension', html);
    }

    async runBlockCode() {
        let serverUrl = window.localStorage.getItem('block_server_ip');
        if (!serverUrl) {
            let res = await window.acode.prompt('Enter PC Engine API URL', 'http://192.168.1.100:8080/api/run');
            if (!res) return;
            if (!res.endsWith('/api/run')) {
                res = res.replace(/\/$/, '') + '/api/run';
            }
            window.localStorage.setItem('block_server_ip', res);
            serverUrl = res;
        }

        const code = editorManager.editor.getValue();
        if (window.toast) window.toast('Running code...', 1000);

        try {
            const response = await fetch(serverUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'text/plain'
                },
                body: code
            });
            const result = await response.json();
            
            if (result.status === 'success') {
                const safeOutput = result.output.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
                const html = `<div style="background:#1e1e1e; color:#d4d4d4; padding:10px; border-radius:8px; font-family:monospace; max-height:300px; overflow-y:auto; white-space:pre-wrap; text-align:left;">${safeOutput}</div>`;
                window.acode.alert('Execution Result', html);
            } else {
                window.acode.alert('Execution Error', `<div style="color:#ff5555; text-align:left;">${result.error}</div>`);
            }
        } catch (e) {
            window.acode.alert('Connection Failed', `Could not connect to ${serverUrl}. Is the PC engine running? Error: ${e.message}\n\nTo change IP, run: window.localStorage.removeItem('block_server_ip') in console, or we will prompt again if you clear it.`);
            window.localStorage.removeItem('block_server_ip'); // Allow re-entering next time
        }
    }

    async destroy() {
        editorManager.off('switch-file', this.onFileUpdate.bind(this));
        editorManager.off('rename-file', this.onFileUpdate.bind(this));
        const style = document.getElementById('block-plugin-style');
        if (style) style.remove();
        if (this.$btn.parentElement) this.$btn.parentElement.removeChild(this.$btn);
    }
}

if (window.acode) {
    const acodePlugin = new BlockPlugin();
    acode.setPluginInit(pluginId, (baseUrl, $page, { cacheFileUrl, cacheFile }) => {
        acodePlugin.baseUrl = baseUrl;
        acodePlugin.init($page);
    }, {
        list: [
            {
                key: "info",
                text: "Block Engine Settings",
                value: "Block mode with Multi-Language Embedded Syntax Highlighting enabled."
            }
        ],
        cb: (key, value) => {}
    });
    
    acode.setPluginUnmount(pluginId, () => {
        acodePlugin.destroy();
    });
}
