const pluginId = "com.blocklang.acode";

const svgIconUrl = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' rx='20' fill='white'/%3E%3Cpath d='M25 25 h30 a15 15 0 0 1 15 15 v5 a15 15 0 0 1 -15 15 h-30 z M25 75 h30 a15 15 0 0 0 15 -15 v-5 a15 15 0 0 0 -15 -15 h-30 z' fill='black'/%3E%3C/svg%3E";

class BlockPlugin {
    async init($page) {
        // Setup Header Icon UI & File Browser Icon
        const style = document.createElement('style');
        style.id = 'block-plugin-style';
        style.innerHTML = `
            .icon-block-lang {
                background-image: url("${svgIconUrl}");
                background-size: cover;
                background-repeat: no-repeat;
                background-position: center;
                width: 26px;
                height: 26px;
                display: inline-block;
                margin: 11px 8px 0 8px;
                cursor: pointer;
                border-radius: 4px;
                float: right;
            }
            .file_type_blk::before, .file_type_block::before {
                content: '' !important;
                display: inline-block !important;
                width: 1.1em;
                height: 1.1em;
                background-image: url("${svgIconUrl}");
                background-size: contain;
                background-repeat: no-repeat;
                background-position: center;
                vertical-align: middle;
            }
        `;
        document.head.appendChild(style);

        this.$btn = document.createElement('span');
        this.$btn.className = 'icon icon-block-lang action-btn';
        this.$btn.onclick = this.showAbout.bind(this);

        this.$runBtn = document.createElement('span');
        this.$runBtn.className = 'icon action-btn';
        this.$runBtn.innerHTML = '▶';
        this.$runBtn.style.color = '#4caf50';
        this.$runBtn.style.fontWeight = 'bold';
        this.$runBtn.style.fontSize = '20px';
        this.$runBtn.style.padding = '10px 10px 0 10px';
        this.$runBtn.style.float = 'right';
        this.$runBtn.style.cursor = 'pointer';
        this.$runBtn.onclick = this.runBlockCode.bind(this);

        // Register Snippets for HTML mode since we use it for Block
        if (window.ace) {
            ace.config.loadModule("ace/snippets/html", (m) => {
                const snippetManager = ace.require("ace/snippets").snippetManager;
                if (!m) m = { snippets: [] };
                m.snippets = m.snippets || [];
                const mySnippets = [
                    { name: "server", content: "<server port=\"${1:8080}\">\n  $2\n</server>", tabTrigger: "server" },
                    { name: "route", content: "<route path=\"${1:/api}\">\n  $2\n</route>", tabTrigger: "route" },
                    { name: "python", content: "<python>\n$1\n</python>", tabTrigger: "python" },
                    { name: "php", content: "<php>\n$1\n</php>", tabTrigger: "php" },
                    { name: "js", content: "<js>\n$1\n</js>", tabTrigger: "js" },
                    { name: "ps", content: "<ps>\n$1\n</ps>", tabTrigger: "ps" }
                ];
                m.snippets.push(...mySnippets);
                snippetManager.register(m.snippets, "html");
            });
        }

        // Bind file updates
        editorManager.on('switch-file', this.onFileUpdate.bind(this));
        editorManager.on('rename-file', this.onFileUpdate.bind(this));
        this.onFileUpdate();
    }

    onFileUpdate() {
        const file = editorManager.activeFile;
        const isBlock = file && (file.filename.endsWith('.blk') || file.filename.endsWith('.block'));
        if (isBlock) {
            // Use HTML mode which correctly lazy-loads in Acode and provides great tag highlighting
            editorManager.editor.getSession().setMode('ace/mode/html');
            
            if (!this.$btn.parentElement) {
                const header = document.querySelector('#main-header') || document.querySelector('header');
                if (header) {
                    header.appendChild(this.$btn);
                    header.appendChild(this.$runBtn);
                }
            }
        } else {
            if (this.$btn.parentElement) {
                this.$btn.parentElement.removeChild(this.$btn);
            }
            if (this.$runBtn.parentElement) {
                this.$runBtn.parentElement.removeChild(this.$runBtn);
            }
        }
    }

    showAbout() {
        const html = `
            <div style="text-align: center;">
                <img src="${svgIconUrl}" style="width: 100px; height: 100px; border-radius: 16px; margin-bottom: 12px; box-shadow: 0 4px 8px rgba(0,0,0,0.3);">
                <h3 style="margin: 0; color: #fff; font-family: 'Inter', sans-serif;">Block Engine</h3>
                <p style="margin: 6px 0 16px 0; color: #aaa; font-size: 14px;">Version 1.0.1</p>
                <a href="https://github.com/Antigravity/BlockEngine" style="display: inline-block; padding: 8px 16px; background-color: #4da6ff; color: #fff; text-decoration: none; border-radius: 8px; font-weight: bold;">Visit Website</a>
            </div>
        `;
        window.acode.alert('About Extension', html);
    }

    async runBlockCode() {
        let serverUrl = window.localStorage.getItem('block_server_ip');
        if (!serverUrl) {
            let res = await window.acode.prompt('Enter PC Engine API URL', 'http://192.168.1.100:8080/api/run');
            if (!res) return;
            if (!res.endsWith('/api/run')) {
                res = res.replace(/\\/$/, '') + '/api/run';
            }
            window.localStorage.setItem('block_server_ip', res);
            serverUrl = res;
        }

        const code = editorManager.editor.getValue();
        if (window.toast) window.toast('Running code...', 1000);

        try {
            const response = await fetch(serverUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'text/plain'
                },
                body: code
            });
            const result = await response.json();
            
            if (result.status === 'success') {
                const safeOutput = result.output.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
                const html = \`<div style="background:#1e1e1e; color:#d4d4d4; padding:10px; border-radius:8px; font-family:monospace; max-height:300px; overflow-y:auto; white-space:pre-wrap; text-align:left;">\${safeOutput}</div>\`;
                window.acode.alert('Execution Result', html);
            } else {
                window.acode.alert('Execution Error', \`<div style="color:#ff5555; text-align:left;">\${result.error}</div>\`);
            }
        } catch (e) {
            window.acode.alert('Connection Failed', \`Could not connect to \${serverUrl}. Is the PC engine running? Error: \${e.message}\\n\\nTo change IP, run: window.localStorage.removeItem('block_server_ip') in console, or we will prompt again if you clear it.\`);
            window.localStorage.removeItem('block_server_ip'); // Allow re-entering next time
        }
    }

    async destroy() {
        editorManager.off('switch-file', this.onFileUpdate.bind(this));
        editorManager.off('rename-file', this.onFileUpdate.bind(this));
        const style = document.getElementById('block-plugin-style');
        if (style) style.remove();
        if (this.$btn.parentElement) this.$btn.parentElement.removeChild(this.$btn);
    }
}

if (window.acode) {
    const acodePlugin = new BlockPlugin();
    acode.setPluginInit(pluginId, (baseUrl, $page, { cacheFileUrl, cacheFile }) => {
        acodePlugin.baseUrl = baseUrl;
        acodePlugin.init($page);
    });
    
    acode.setPluginUnmount(pluginId, () => {
        acodePlugin.destroy();
    });
}
