const pluginId = "com.blocklang.acode";

const svgIconUrl = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIj48cmVjdCB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgcng9IjIwIiBmaWxsPSJ3aGl0ZSIvPjxwYXRoIGQ9Ik0yNSAyNSBoMzAgYTE1IDE1IDAgMCAxIDE1IDE1IHY1IGExNSAxNSAwIDAgMSAtMTUgMTUgaC0zMCB6IE0yNSA3NSBoMzAgYTE1IDE1IDAgMCAwIDE1IC0xNSB2LTUgYTE1IDE1IDAgMCAwIC0xNSAtMTUgaC0zMCB6IiBmaWxsPSJibGFjayIvPjwvc3ZnPg==";

class BlockPlugin {
    async init($page) {
        const style = document.createElement('style');
        style.id = 'block-plugin-style';
        style.innerHTML = "\n            .icon-block-lang {\n                background-image: url('" + svgIconUrl + "');\n                background-size: cover;\n                background-repeat: no-repeat;\n                background-position: center;\n                width: 26px;\n                height: 26px;\n                display: inline-block;\n                margin: 11px 8px 0 8px;\n                cursor: pointer;\n                border-radius: 4px;\n                float: right;\n            }\n            .file_type_blk::before, .file_type_block::before {\n                content: '' !important;\n                display: inline-block !important;\n                width: 1.1em;\n                height: 1.1em;\n                background-image: url('" + svgIconUrl + "');\n                background-size: contain;\n                background-repeat: no-repeat;\n                background-position: center;\n                vertical-align: middle;\n            }\n        ";
        document.head.appendChild(style);

        this.$btn = document.createElement('span');
        this.$btn.className = 'icon icon-block-lang action-btn';
        this.$btn.onclick = this.showAbout.bind(this);

        this.$runBtn = document.createElement('span');
        this.$runBtn.className = 'icon action-btn';
        this.$runBtn.innerHTML = '▶';
        this.$runBtn.style.color = '#4caf50';
        this.$runBtn.style.fontWeight = 'bold';
        this.$runBtn.style.fontSize = '20px';
        this.$runBtn.style.padding = '10px 10px 0 10px';
        this.$runBtn.style.float = 'right';
        this.$runBtn.style.cursor = 'pointer';
        this.$runBtn.onclick = this.runBlockCode.bind(this);

        if (window.ace) {
            ace.config.loadModule("ace/snippets/html", function(m) {
                const snippetManager = ace.require("ace/snippets").snippetManager;
                if (!m) m = { snippets: [] };
                m.snippets = m.snippets || [];
                const mySnippets = [
                    { name: "server", content: "<server port=\"${1:8080}\">\n  $2\n</server>", tabTrigger: "server" },
                    { name: "python", content: "<python>\n$1\n</python>", tabTrigger: "python" }
                ];
                m.snippets.push.apply(m.snippets, mySnippets);
                snippetManager.register(m.snippets, "html");
            });
        }

        editorManager.on('switch-file', this.onFileUpdate.bind(this));
        editorManager.on('rename-file', this.onFileUpdate.bind(this));
        this.onFileUpdate();
    }

    onFileUpdate() {
        const file = editorManager.activeFile;
        const isBlock = file && (file.filename.endsWith('.blk') || file.filename.endsWith('.block'));
        if (isBlock) {
            editorManager.editor.getSession().setMode('ace/mode/html');
            const header = document.querySelector('#main-header') || document.querySelector('header');
            if (header && !this.$btn.parentElement) {
                header.appendChild(this.$btn);
                header.appendChild(this.$runBtn);
            }
        } else {
            if (this.$btn.parentElement) this.$btn.parentElement.removeChild(this.$btn);
            if (this.$runBtn.parentElement) this.$runBtn.parentElement.removeChild(this.$runBtn);
        }
    }

    showAbout() {
        const html = "<div style=\"text-align: center;\">" +
            "<img src=\"" + svgIconUrl + "\" style=\"width: 100px; height: 100px; border-radius: 16px; margin-bottom: 12px; box-shadow: 0 4px 8px rgba(0,0,0,0.3);\">" +
            "<h3 style=\"margin: 0; color: #fff; font-family: 'Inter', sans-serif;\">Block Engine</h3>" +
            "<p style=\"margin: 6px 0 16px 0; color: #aaa; font-size: 14px;\">Version 1.0.1</p>" +
            "</div>";
        window.acode.alert('About Extension', html);
    }

    async runBlockCode() {
        let serverUrl = window.localStorage.getItem('block_server_ip');
        if (!serverUrl) {
            let res = await window.acode.prompt('Enter PC Engine API URL', 'http://192.168.1.100:8080/api/run');
            if (!res) return;
            if (res.endsWith('/')) res = res.substring(0, res.length - 1);
            if (!res.endsWith('/api/run')) res = res + '/api/run';
            window.localStorage.setItem('block_server_ip', res);
            serverUrl = res;
        }

        const code = editorManager.editor.getValue();
        if (window.toast) window.toast('Running code...', 1000);

        try {
            const response = await fetch(serverUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'text/plain' },
                body: code
            });
            const result = await response.json();
            
            if (result.status === 'success') {
                const safeOutput = result.output.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
                const html = "<div style=\"background:#1e1e1e; color:#d4d4d4; padding:10px; border-radius:8px; font-family:monospace; max-height:300px; overflow-y:auto; white-space:pre-wrap; text-align:left;\">" + safeOutput + "</div>";
                window.acode.alert('Execution Result', html);
            } else {
                window.acode.alert('Execution Error', "<div style=\"color:#ff5555; text-align:left;\">" + result.error + "</div>");
            }
        } catch (e) {
            window.acode.alert('Connection Failed', "Could not connect to " + serverUrl + ". Is the PC engine running?\nError: " + e.message);
            window.localStorage.removeItem('block_server_ip');
        }
    }

    async destroy() {
        editorManager.off('switch-file', this.onFileUpdate.bind(this));
        editorManager.off('rename-file', this.onFileUpdate.bind(this));
        const style = document.getElementById('block-plugin-style');
        if (style) style.remove();
        if (this.$btn.parentElement) this.$btn.parentElement.removeChild(this.$btn);
        if (this.$runBtn.parentElement) this.$runBtn.parentElement.removeChild(this.$runBtn);
    }
}

if (window.acode) {
    const acodePlugin = new BlockPlugin();
    acode.setPluginInit(pluginId, function(baseUrl, $page, options) {
        acodePlugin.baseUrl = baseUrl;
        acodePlugin.init($page);
    });
    
    acode.setPluginUnmount(pluginId, function() {
        acodePlugin.destroy();
    });
}
