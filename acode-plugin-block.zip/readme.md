# Block Engine Plugin for Acode

This is the official Block Engine extension for the Acode editor on Android.

## Features

- **Syntax Highlighting**: Supports syntax highlighting for `.blk` and `.block` files, natively parsing XML-like structures with embedded `<python>`, `<php>`, `<html>`, and `<server>` tags.
- **Autocomplete & Snippets**: Quick tags generation for `server`, `route`, `python`, `php`, `ps`, and `json`.

## Future Features
- We are actively looking into bringing Remote Execution (via LAN Relay Server) to Android!

## Usage
Just open a `.blk` file and enjoy the coding experience.
